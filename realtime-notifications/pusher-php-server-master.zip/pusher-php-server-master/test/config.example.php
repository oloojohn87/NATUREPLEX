<?php
define('PUSHERAPP_APPID', '');
define('PUSHERAPP_AUTHKEY', '');
define('PUSHERAPP_SECRET', '');
?>