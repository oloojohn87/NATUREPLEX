<?php

class TestLogger {
	public function log( $msg ) {
		print_r( "\n" . $msg  );
	}
}